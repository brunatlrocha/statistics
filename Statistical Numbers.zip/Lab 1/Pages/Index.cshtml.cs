using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Lab1.Pages
{
    public class IndexModel : PageModel
    {
        [BindProperty]
        public string[] Numbers { get; set; } = new string[4];
        public string[] ErrorMessages { get; set; } = new string[4];
        public double Total { get; set; }
        public double Average { get; set; }
        public double Maximum { get; set; }
        public double Minimum { get; set; }
        public bool ShowResults { get; set; }
        public string GeneralErrorMessage { get; set; }

        public void OnGet()
        {
           
        }

        public void OnPost()
        {
            List<double> validNumbers = new List<double>();
            bool hasErrors = false;

            for (int i = 0; i < Numbers.Length; i++)
            {
                if (double.TryParse(Numbers[i], out double result))
                {
                    validNumbers.Add(result);
                    ErrorMessages[i] = string.Empty;
                }
                else if (!string.IsNullOrEmpty(Numbers[i]))
                {
                    ErrorMessages[i] = "Invalid number";
                    hasErrors = true;
                }
                else
                {
                    ErrorMessages[i] = string.Empty;
                }
            }

            if (validNumbers.Count < 2)
            {
                GeneralErrorMessage = "Please enter at least two valid numbers.";
                hasErrors = true;
            }

            if (!hasErrors)
            {
                Total = validNumbers.Sum();
                Average = validNumbers.Average();
                Maximum = validNumbers.Max();
                Minimum = validNumbers.Min();
                ShowResults = true;
                GeneralErrorMessage = string.Empty;
            }
            else
            {
                ShowResults = false;
            }
        }
    }
}
